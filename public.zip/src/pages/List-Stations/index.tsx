import * as React from 'react';

const StationsList = () => (
  <>
    <h1>Lista de estações</h1>
    <div>
      <h2>Banner</h2>
    </div>
  </>
);

export default StationsList;