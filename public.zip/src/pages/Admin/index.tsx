import * as React from 'react';

const Admin = () => (
  <>
    <h1>Administrador</h1>
    <div>
      <h2>Banner</h2>
    </div>
  </>
);

export default Admin;