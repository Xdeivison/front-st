import * as React from 'react';

const Contact = () => (
  <>
    <h1>Contato</h1>
    <div>
      <h2>Banner</h2>
    </div>
  </>
);

export default Contact;