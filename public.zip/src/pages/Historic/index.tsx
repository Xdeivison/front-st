import * as React from 'react';

const Historic = () => (
  <>
    <h1>Historico</h1>
    <div>
      <h2>Banner</h2>
    </div>
  </>
);

export default Historic;