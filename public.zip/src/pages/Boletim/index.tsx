import * as React from 'react';

const Boletim = () => (
  <>
    <h1>Boletim</h1>
    <div>
      <h2>Banner</h2>
    </div>
  </>
);

export default Boletim;