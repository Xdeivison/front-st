declare module 'mapbox-gl' {
    const mapboxgl: any;
    export = mapboxgl;
  }