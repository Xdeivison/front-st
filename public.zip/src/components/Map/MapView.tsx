import React, { useRef, useEffect, useState } from 'react';
import mapboxgl from 'mapbox-gl';
// import { styles } from '../data/stylesMap/styles';
import api from '../../services/api';

mapboxgl.accessToken = 'pk.eyJ1Ijoic2F0ZGVzIiwiYSI6ImNsbWd1eGJrZjBjamozcnNlbDVhN2c0M2MifQ.PS-DD0vWP5d1X8e-VfuTfQ';

function MapView() {
  const mapContainer = useRef<HTMLDivElement | null>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [longitude, setLongitude] = useState<number>(-40.3381);
  const [latitude, setLatitude] = useState<number>(-20.3222);
  const [zoom, setZoom] = useState<number>(11.15);
  // const [selectedStyle, setSelectedStyle] = useState(styles[0]);

  useEffect(() => {
    const fetchData = async () => {
      if (!map.current && mapContainer.current) {
        // Crie o mapa
        map.current = new mapboxgl.Map({
          container: mapContainer.current,
          style: 'mapbox://styles/mapbox/streets-v12',
          center: [longitude, latitude],
          zoom: zoom,
        });
      }

      if (map.current) {
        map.current.on('load', async () => {
          // Pegue os dados da API
          const response = await api.get('/stations');

          // Adicione os ícones dos institutos ao mapa
          const institutes = [...new Set<string>(response.data.data.map((station: any) => station.name_institute))];

          institutes.forEach((institute) => {
            const instituteStations = response.data.data.filter(
              (station: any) => station.name_institute === institute
            );

            map.current?.addSource(institute, {
              type: 'geojson',
              data: {
                type: 'FeatureCollection',
                features: instituteStations.map((station: any) => ({
                  type: 'Feature',
                  properties: {
                    description: `
                    <p><strong>${station.name_county}</strong></p>
                    <p><strong>${station.name}</strong></p>
                    <p><strong>${station.longitude}</strong></p>
                    <p><strong>${station.latitude}</strong></p>
                    `, // Customize the description as needed
                  },
                  geometry: {
                    type: 'Point',
                    coordinates: [parseFloat(station.longitude), parseFloat(station.latitude)],
                  },
                })),
              },
            });

            map.current?.addLayer({
              id: `places-${institute}`,
              type: 'circle',
              source: institute,
              paint: {
                'circle-color': '#F78C45',
                'circle-radius': 6,
                'circle-stroke-width': 2,
                'circle-stroke-color': 'rgb(247,140,69)',
              },
            });

            
  
            map.current?.on('mouseenter', `places-${institute}`, (e) => {
              if (map.current) {
                map.current.getCanvas().style.cursor = 'pointer';
              }

              if (e.features && e.features[0]) {
                const feature = e.features[0];
                const coordinates = (feature.geometry as GeoJSON.Point).coordinates;

                if (coordinates) {
                  const description = feature.properties?.description;

                  while (Math.abs(e.lngLat.lng - coordinates[0]) > 180) {
                    coordinates[0] += e.lngLat.lng > coordinates[0] ? 360 : -360;
                  }

                  const popup = new mapboxgl.Popup({
                    closeButton: false,
                    closeOnClick: false,
                  });

                  popup.setLngLat(coordinates).setHTML(description).addTo(map.current);
                }
              }
            });
            
            map.current?.on('mouseleave', `places-${institute}`, (e) => {
              if (map.current)
                map.current.getCanvas().style.cursor = '';
            });
          });

          

        });
      }
    };

    fetchData();
  }, [longitude, latitude, zoom]);

  // O restante do seu componente MapView permanece inalterado

  return (
    <div id="map">
      <div ref={mapContainer} className="map-container" />
    </div>
  );
}

export default MapView;